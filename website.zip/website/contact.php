<?php 
	include('config.php');
	include('./includes/header.php'); ?>

<div id="wrapper">

		<h1>Welcome to our contact page</h1>
			<!-- <main style="<?php echo $background; ?>"> -->
            <!-- <main> -->
				<div style="padding: 20px;">

                <?php
                    include('./includes/form.php');
                ?>
							
				</div>
					<!-- </main> -->
		
	<!-- <aside>
    <h3>This is my aside</h3>
    
    
		</aside> -->

	</div>  <!-- end of wrapper -->

	<?php include('./includes/footer.php'); ?>


