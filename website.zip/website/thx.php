
<?php 
	include('config.php');
	include('./includes/header.php'); ?>

<div id="wrapper">

		<h1>Thank You for your requests</h1>
		<h2>A member from our team will get back to you with the requested information</h2>
		<h2>We usually get back to you within 24 to 48 hours Monday thru Friday</h2>
			<!-- <main style="<?php echo $background; ?>"> -->
            <!-- <main> -->
				<!-- <div style="padding: 20px;">


							
				</div> -->
					<!-- </main> -->
		
	<!-- <aside>
    <h3>This is my aside</h3>
    
    
		</aside> -->

	</div>  <!-- end of wrapper -->

	<?php include('./includes/footer.php'); ?>


