
<?php 
	include('config.php');
	include('./includes/header.php'); ?>

	<div id="wrapper">	
	<div id="hero">
	<img src="images/twelve.jpg" alt="twelve is greater than 3">
	
	</div>
			<!-- end hero -->	
			<main>
				<h1>Welcome to our Web App Programming Class!</h1>
				<h2>We are going to learn PHP!</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eos repellat facere tenetur, ducimus cum reprehenderit alias. Sequi consequatur non molestiae placeat hic molestias ipsum deserunt, quod sapiente amet explicabo maiores labore, architecto animi velit in tenetur. Sapiente et impedit, aliquam a pariatur amet, quis adipisci laboriosam ullam, provident, natus praesentium. </p>
				<h2>Another Headline 2!</h2>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Porro laudantium omnis necessitatibus nostrum sit soluta nulla tempora, dolorum ad eos blanditiis non, consequuntur nesciunt quis ipsam. Eos doloribus rerum, libero fugit repudiandae incidunt, sint facilis, quisquam saepe earum recusandae voluptatibus!</p>
				</main>


		
			<aside>
				<h3>This is our headline three in our good looking aside</h3>
				<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Error, consectetur doloribus mollitia, illo labore commodi atque dignissimos repellat, eveniet facilis voluptatem. Iste magnam atque beatae libero suscipit rem porro quos, eveniet, neque animi, aliquam perspiciatis optio adipisci voluptatem fugiat blanditiis!</p>
				
				</aside>
			
			</div>  <!-- end of wrapper --> 
			
			 

	<?php include('./includes/footer.php'); ?>